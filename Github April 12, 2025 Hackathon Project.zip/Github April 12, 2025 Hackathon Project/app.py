from flask import Flask, request, jsonify, render_template
from web3 import Web3
import os
import json
from dotenv import load_dotenv
from eth_account.messages import encode_defunct
from web3.exceptions import ContractLogicError
from auth import auth, token_required
import models

# Load environment variables
load_dotenv()

app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv('JWT_SECRET_KEY')

# Register blueprints
app.register_blueprint(auth, url_prefix='/auth')

# Connect to Sepolia network with fallbacks
def get_web3_provider():
    # Try Infura first
    infura_url = os.getenv("INFURA_URL")
    if infura_url:
        provider = Web3.HTTPProvider(infura_url)
        w3 = Web3(provider)
        if w3.is_connected():
            print(f"Connected to Ethereum network via Infura: {w3.client_version}")
            return w3
    
    # Try Alchemy as backup
    alchemy_url = os.getenv("ALCHEMY_URL")
    if alchemy_url:
        provider = Web3.HTTPProvider(alchemy_url)
        w3 = Web3(provider)
        if w3.is_connected():
            print(f"Connected to Ethereum network via Alchemy: {w3.client_version}")
            return w3
    
    # Try public endpoint as last resort
    public_url = "https://rpc.sepolia.org"
    provider = Web3.HTTPProvider(public_url)
    w3 = Web3(provider)
    if w3.is_connected():
        print(f"Connected to Ethereum network via public RPC: {w3.client_version}")
        return w3
    
    print("Failed to connect to any Ethereum provider!")
    return Web3(Web3.HTTPProvider(infura_url))  # Return the original even if it fails

# Get Web3 instance
w3 = get_web3_provider()
if not w3.is_connected():
    print("Failed to connect to Ethereum network!")
else:
    print(f"Connected to Ethereum network: {w3.client_version}")

# Load wallet
PRIVATE_KEY = os.getenv("PRIVATE_KEY")
if not PRIVATE_KEY.startswith('0x'):
    PRIVATE_KEY = '0x' + PRIVATE_KEY
ACCOUNT = w3.eth.account.from_key(PRIVATE_KEY)
print(f"Using account: {ACCOUNT.address}")

# Load contract ABI and connect to contract
with open("contract_abi.json") as f:
    abi = json.load(f)

CONTRACT_ADDRESS = Web3.to_checksum_address(os.getenv("CONTRACT_ADDRESS"))
print(f"Connected to contract at: {CONTRACT_ADDRESS}")
contract = w3.eth.contract(address=CONTRACT_ADDRESS, abi=abi)

def validate_address(address):
    try:
        return Web3.to_checksum_address(address)
    except ValueError:
        return None

@app.route("/")
def home():
    return render_template('index.html')

@app.route("/balance/<address>", methods=["GET"])
def get_balance(address):
    try:
        address = validate_address(address)
        if not address:
            return jsonify({"error": "Invalid address format"}), 400
            
        # First, check if the account exists in the contract
        try:
            # Check contract state
            print(f"Checking contract at {CONTRACT_ADDRESS}...")
            print(f"Connected to network: {w3.client_version}")
            print(f"Block number: {w3.eth.block_number}")
            
            # Get contract balance
            print(f"Attempting to get balance for: {address}")
            contract_balance = contract.functions.getBalance(address).call()
            contract_eth = w3.from_wei(contract_balance, 'ether')
            print(f"Contract balance: {contract_balance} wei ({contract_eth} ETH)")
            
            # Get native ETH balance
            native_balance = w3.eth.get_balance(address)
            native_eth = w3.from_wei(native_balance, 'ether')
            
            return jsonify({
                "address": address,
                "contract_balance_eth": str(contract_eth),
                "contract_balance_wei": contract_balance,
                "native_eth_balance": str(native_eth),
                "native_eth_wei": native_balance
            })
        except Exception as e:
            # If the account doesn't exist yet, return 0 balance
            print(f"Error checking balance: {str(e)}")
            
            # Still get the native ETH balance
            native_balance = w3.eth.get_balance(address)
            native_eth = w3.from_wei(native_balance, 'ether')
            
            return jsonify({
                "address": address,
                "contract_balance_eth": "0",
                "contract_balance_wei": 0,
                "native_eth_balance": str(native_eth),
                "native_eth_wei": native_balance,
                "note": "No funds deposited in contract yet or contract error"
            })
    except Exception as e:
        print(f"Exception in get_balance: {str(e)}")
        return jsonify({"error": str(e)}), 500

@app.route("/deposit", methods=["POST"])
@token_required
def deposit(current_user):
    try:
        data = request.get_json()
        if not data or 'amount' not in data:
            return jsonify({"error": "Amount is required"}), 400
            
        amount = int(data['amount'])
        if amount <= 0:
            return jsonify({"error": "Amount must be greater than 0"}), 400

        # Use the user's ethereum address if available
        address_to_use = current_user.get('eth_address', ACCOUNT.address)
        
        nonce = w3.eth.get_transaction_count(ACCOUNT.address)
        gas_price = w3.eth.gas_price
        
        txn = contract.functions.deposit().build_transaction({
            "from": ACCOUNT.address,
            "value": amount,
            "nonce": nonce,
            "gas": 200000,
            "gasPrice": gas_price
        })

        signed_txn = w3.eth.account.sign_transaction(txn, private_key=PRIVATE_KEY)
        tx_hash = w3.eth.send_raw_transaction(signed_txn.raw_transaction)
        
        # Record the transaction
        models.record_transaction(
            current_user['_id'], 
            'deposit', 
            amount, 
            tx_hash.hex()
        )
        
        return jsonify({
            "status": "success",
            "tx_hash": tx_hash.hex(),
            "message": "Deposit transaction submitted"
        })
    except ContractLogicError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        print(f"Exception in deposit: {str(e)}")
        return jsonify({"error": str(e)}), 500

@app.route("/withdraw", methods=["POST"])
@token_required
def withdraw(current_user):
    try:
        data = request.get_json()
        if not data or 'amount' not in data:
            return jsonify({"error": "Amount is required"}), 400
            
        amount = int(data['amount'])
        if amount <= 0:
            return jsonify({"error": "Amount must be greater than 0"}), 400

        # Use the user's ethereum address
        address_to_use = current_user.get('eth_address')
        
        nonce = w3.eth.get_transaction_count(ACCOUNT.address)
        gas_price = w3.eth.gas_price
        
        txn = contract.functions.withdraw(amount).build_transaction({
            "from": ACCOUNT.address,
            "nonce": nonce,
            "gas": 200000,
            "gasPrice": gas_price
        })

        signed_txn = w3.eth.account.sign_transaction(txn, private_key=PRIVATE_KEY)
        tx_hash = w3.eth.send_raw_transaction(signed_txn.raw_transaction)
        
        # Record the transaction
        models.record_transaction(
            current_user['_id'], 
            'withdraw', 
            amount, 
            tx_hash.hex()
        )
        
        return jsonify({
            "status": "success",
            "tx_hash": tx_hash.hex(),
            "message": "Withdrawal transaction submitted"
        })
    except ContractLogicError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        print(f"Exception in withdraw: {str(e)}")
        return jsonify({"error": str(e)}), 500

@app.route("/transfer", methods=["POST"])
@token_required
def transfer(current_user):
    try:
        data = request.get_json()
        if not data or 'to' not in data or 'amount' not in data:
            return jsonify({"error": "Recipient address and amount are required"}), 400
            
        to_address = validate_address(data['to'])
        if not to_address:
            return jsonify({"error": "Invalid recipient address"}), 400
            
        amount = int(data['amount'])
        if amount <= 0:
            return jsonify({"error": "Amount must be greater than 0"}), 400

        # Get current sender's address (from the authenticated user)
        from_address = current_user.get('eth_address', ACCOUNT.address)
        
        print(f"Transfer request: {from_address} -> {to_address}, Amount: {amount} wei")
        
        # Check balance before transfer
        try:
            balance = contract.functions.getBalance(from_address).call()
            if balance < amount:
                return jsonify({"error": f"Insufficient balance. You have {w3.from_wei(balance, 'ether')} ETH, but trying to send {w3.from_wei(amount, 'ether')} ETH"}), 400
        except Exception as e:
            print(f"Balance check error: {str(e)}")
            # If balance check fails, might be because user has no funds in contract
            return jsonify({"error": "You don't have funds in the contract. You need to deposit first."}), 400

        nonce = w3.eth.get_transaction_count(ACCOUNT.address)
        gas_price = w3.eth.gas_price
        
        # Build transaction for the transfer function
        txn = contract.functions.transfer(to_address, amount).build_transaction({
            "from": ACCOUNT.address,
            "nonce": nonce,
            "gas": 200000,
            "gasPrice": gas_price
        })

        signed_txn = w3.eth.account.sign_transaction(txn, private_key=PRIVATE_KEY)
        tx_hash = w3.eth.send_raw_transaction(signed_txn.raw_transaction)
        
        # Record the transaction
        transaction = models.record_transaction(
            current_user['_id'], 
            'transfer', 
            amount, 
            tx_hash.hex()
        )
        
        return jsonify({
            "status": "success",
            "tx_hash": tx_hash.hex(),
            "message": f"Transfer of {w3.from_wei(amount, 'ether')} ETH to {to_address} submitted"
        })
    except ContractLogicError as e:
        error_msg = str(e)
        print(f"Contract logic error in transfer: {error_msg}")
        return jsonify({"error": error_msg}), 400
    except Exception as e:
        print(f"Exception in transfer: {str(e)}")
        return jsonify({"error": str(e)}), 500

@app.route("/transactions", methods=["GET"])
@token_required
def get_transactions(current_user):
    try:
        # Get all transactions for the user
        user_transactions = list(models.transactions.find({"user_id": current_user['_id']}))
        
        # Convert ObjectID to string for JSON serialization
        for tx in user_transactions:
            tx['_id'] = str(tx['_id'])
            
        return jsonify({
            "transactions": user_transactions
        })
    except Exception as e:
        print(f"Exception in get_transactions: {str(e)}")
        return jsonify({"error": str(e)}), 500

@app.route("/contract-address", methods=["GET"])
def get_contract_address():
    try:
        return jsonify({
            "address": CONTRACT_ADDRESS,
            "network": "Sepolia"
        })
    except Exception as e:
        print(f"Exception in get_contract_address: {str(e)}")
        return jsonify({"error": str(e)}), 500

@app.route("/check-tx/<tx_hash>", methods=["GET"])
def check_transaction(tx_hash):
    try:
        # Verify the transaction hash format
        if not Web3.is_checksum_address('0x' + tx_hash[2:].zfill(40)[:40]):
            return jsonify({"error": "Invalid transaction hash format"}), 400
            
        # Get transaction receipt
        try:
            receipt = w3.eth.get_transaction_receipt(tx_hash)
            tx = w3.eth.get_transaction(tx_hash)
            
            # Check if the transaction was to our contract
            to_contract = receipt['to'] and receipt['to'].lower() == CONTRACT_ADDRESS.lower()
            
            # Get sender balance in contract
            sender_balance = 0
            if tx and tx['from']:
                try:
                    sender_balance = contract.functions.getBalance(tx['from']).call()
                except Exception as e:
                    print(f"Error getting sender balance: {str(e)}")
            
            return jsonify({
                "status": "confirmed" if receipt['status'] == 1 else "failed",
                "block_number": receipt['blockNumber'],
                "gas_used": receipt['gasUsed'],
                "from": tx['from'] if tx else None,
                "to": tx['to'] if tx else None,
                "value": w3.from_wei(tx['value'], 'ether') if tx else None,
                "to_contract": to_contract,
                "sender_balance_in_contract": w3.from_wei(sender_balance, 'ether'),
                "transaction_hash": tx_hash
            })
            
        except Exception as e:
            print(f"Error checking transaction: {str(e)}")
            return jsonify({
                "status": "pending",
                "error": str(e),
                "transaction_hash": tx_hash
            })
            
    except Exception as e:
        print(f"Exception in check_transaction: {str(e)}")
        return jsonify({"error": str(e)}), 500

@app.route("/record-transaction", methods=["POST"])
@token_required
def record_transaction(current_user):
    try:
        data = request.get_json()
        if not data or 'transaction_type' not in data or 'amount' not in data or 'tx_hash' not in data:
            return jsonify({"error": "Transaction type, amount, and hash are required"}), 400
            
        transaction_type = data['transaction_type']
        amount = data['amount']
        tx_hash = data['tx_hash']
        to_address = data.get('to_address', None)
        
        # Record the transaction in the database
        transaction = models.record_transaction(
            current_user['_id'], 
            transaction_type, 
            amount, 
            tx_hash,
            to_address=to_address
        )
        
        return jsonify({
            "status": "success",
            "message": "Transaction recorded successfully"
        })
    except Exception as e:
        print(f"Exception in record_transaction: {str(e)}")
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(debug=True, port=5001)
