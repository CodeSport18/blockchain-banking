from flask import Blueprint, request, jsonify, session
import jwt
import datetime
import os
from dotenv import load_dotenv
from web3 import Web3
from web3.auto import w3
from eth_account.messages import encode_defunct
import models
from functools import wraps
import traceback

# Load environment variables
load_dotenv()

# Initialize blueprint
auth = Blueprint('auth', __name__)

# JWT settings
JWT_SECRET_KEY = os.getenv("JWT_SECRET_KEY")
JWT_EXPIRATION_DAYS = 7

# Middleware for authentication
def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = None
        auth_header = request.headers.get('Authorization')
        
        if auth_header and auth_header.startswith('Bearer '):
            token = auth_header.split(' ')[1]
        
        if not token:
            return jsonify({"error": "Authentication token is missing"}), 401
        
        try:
            data = jwt.decode(token, JWT_SECRET_KEY, algorithms=["HS256"])
            current_user = models.get_user_by_id(data['user_id'])
            
            if not current_user:
                return jsonify({"error": "Invalid authentication token"}), 401
                
        except:
            return jsonify({"error": "Invalid authentication token"}), 401
            
        return f(current_user, *args, **kwargs)
    
    return decorated

@auth.route('/register', methods=['POST'])
def register():
    try:
        data = request.get_json()
        print(f"Registration data received: {data}")
        
        # Validate required fields
        required_fields = ['username', 'email', 'password', 'eth_address']
        for field in required_fields:
            if field not in data:
                return jsonify({"error": f"{field} is required"}), 400
        
        username = data['username']
        email = data['email']
        password = data['password']
        eth_address = data['eth_address']
        
        # Validate Ethereum address
        try:
            eth_address = Web3.to_checksum_address(eth_address)
        except Exception as e:
            print(f"Invalid ETH address: {str(e)}")
            return jsonify({"error": "Invalid Ethereum address"}), 400
        
        # Create user
        user, error = models.create_user(username, email, password, eth_address)
        
        if error:
            print(f"Error creating user: {error}")
            return jsonify({"error": error}), 400
        
        # Generate JWT token
        token = jwt.encode({
            'user_id': user['_id'],
            'exp': datetime.datetime.utcnow() + datetime.timedelta(days=JWT_EXPIRATION_DAYS)
        }, JWT_SECRET_KEY)
        
        print(f"User registered successfully: {username}")
        return jsonify({
            "message": "User registered successfully",
            "token": token,
            "user": user
        }), 201
    except Exception as e:
        print(f"Exception in register: {str(e)}")
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500

@auth.route('/test-mongo', methods=['GET'])
def test_mongo():
    try:
        # Check MongoDB connection
        collections = models.db.list_collection_names()
        users_count = models.users.count_documents({})
        
        # Test create user
        test_user = {
            "username": f"test_user_{datetime.datetime.utcnow().timestamp()}",
            "email": f"test_{datetime.datetime.utcnow().timestamp()}@example.com",
            "password": "test_password",
            "eth_address": "0x5531E57644628C775fC3a4EB1968e027e7727E9F"
        }
        
        status = {
            "mongodb_connected": True,
            "collections": collections,
            "users_count": users_count,
            "test_user": test_user
        }
        
        # Try creating test user
        try:
            user, error = models.create_user(
                test_user["username"], 
                test_user["email"], 
                test_user["password"], 
                test_user["eth_address"]
            )
            
            if error:
                status["create_user_error"] = error
            else:
                status["create_user_success"] = True
                status["created_user"] = user
        except Exception as e:
            status["create_user_error"] = str(e)
            traceback.print_exc()
        
        return jsonify(status)
    except Exception as e:
        traceback.print_exc()
        return jsonify({"error": str(e), "mongodb_connected": False}), 500

@auth.route('/login', methods=['POST'])
def login():
    try:
        data = request.get_json()
        print(f"Login data received: {data}")
        
        # Validate required fields
        if 'email_or_username' not in data or 'password' not in data:
            print("Missing email/username or password")
            return jsonify({"error": "Email/username and password are required"}), 400
        
        email_or_username = data['email_or_username']
        password = data['password']
        
        print(f"Attempting login for user: {email_or_username}")
        
        # Authenticate user
        user, error = models.authenticate_user(email_or_username, password)
        
        if error:
            print(f"Authentication error: {error}")
            return jsonify({"error": error}), 401
        
        # Generate JWT token
        token = jwt.encode({
            'user_id': user['_id'],
            'exp': datetime.datetime.utcnow() + datetime.timedelta(days=JWT_EXPIRATION_DAYS)
        }, JWT_SECRET_KEY)
        
        print(f"Login successful for user: {email_or_username}")
        return jsonify({
            "message": "Login successful",
            "token": token,
            "user": user
        })
    except Exception as e:
        print(f"Exception in login: {str(e)}")
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500

@auth.route('/verify-wallet', methods=['POST'])
def verify_wallet():
    data = request.get_json()
    
    # Validate required fields
    if 'address' not in data or 'signature' not in data or 'message' not in data:
        return jsonify({"error": "Address, signature, and message are required"}), 400
    
    eth_address = data['address']
    signature = data['signature']
    message = data['message']
    
    # Validate Ethereum address
    try:
        eth_address = Web3.to_checksum_address(eth_address)
    except:
        return jsonify({"error": "Invalid Ethereum address"}), 400
    
    # Check if the address is registered
    user = models.get_user_by_eth_address(eth_address)
    if not user:
        return jsonify({"error": "Ethereum address not registered"}), 404
    
    # Verify signature
    try:
        message_hash = encode_defunct(text=message)
        recovered_address = w3.eth.account.recover_message(message_hash, signature=signature)
        
        if recovered_address.lower() != eth_address.lower():
            return jsonify({"error": "Invalid signature"}), 401
        
        # Generate JWT token
        token = jwt.encode({
            'user_id': user['_id'],
            'exp': datetime.datetime.utcnow() + datetime.timedelta(days=JWT_EXPIRATION_DAYS)
        }, JWT_SECRET_KEY)
        
        return jsonify({
            "message": "Wallet verified successfully",
            "token": token,
            "user": user
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@auth.route('/me', methods=['GET'])
@token_required
def get_me(current_user):
    return jsonify({"user": current_user})

@auth.route('/update-profile', methods=['PUT'])
@token_required
def update_profile(current_user):
    data = request.get_json()
    
    # Get fields that can be updated
    allowed_fields = ['username', 'email']
    update_data = {k: v for k, v in data.items() if k in allowed_fields}
    
    if not update_data:
        return jsonify({"error": "No valid fields to update"}), 400
    
    # Update user
    success = models.update_user(current_user['_id'], update_data)
    
    if not success:
        return jsonify({"error": "Failed to update profile"}), 500
    
    # Get updated user
    updated_user = models.get_user_by_id(current_user['_id'])
    
    return jsonify({
        "message": "Profile updated successfully",
        "user": updated_user
    })

@auth.route('/create-test-user', methods=['GET'])
def create_test_user():
    try:
        # Create a test user with known credentials
        test_username = "testuser"
        test_email = "test@example.com"
        test_password = "password123"
        test_eth_address = "0x5531E57644628C775fC3a4EB1968e027e7727E9F"
        
        # Check if user already exists
        existing_user = models.users.find_one({"$or": [
            {"username": test_username}, 
            {"email": test_email},
            {"eth_address": test_eth_address}
        ]})
        
        if existing_user:
            return jsonify({
                "message": "Test user already exists",
                "username": test_username,
                "email": test_email,
                "password": test_password,
                "eth_address": test_eth_address,
                "note": "Use these credentials to log in"
            })
        
        # Create new test user
        user, error = models.create_user(
            test_username, 
            test_email, 
            test_password, 
            test_eth_address
        )
        
        if error:
            return jsonify({"error": error}), 400
        
        return jsonify({
            "message": "Test user created successfully",
            "username": test_username,
            "email": test_email,
            "password": test_password,
            "eth_address": test_eth_address,
            "note": "Use these credentials to log in"
        })
    except Exception as e:
        print(f"Exception in create_test_user: {str(e)}")
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500

@auth.route('/list-users', methods=['GET'])
def list_users():
    try:
        # List all users in the database
        all_users = list(models.users.find({}, {"password": 0}))
        
        # Convert ObjectIDs to strings for JSON serialization
        for user in all_users:
            if "_id" in user:
                user["_id"] = str(user["_id"])
        
        return jsonify({
            "total_users": len(all_users),
            "users": all_users,
            "mongodb_uri": os.getenv("MONGO_URI")
        })
    except Exception as e:
        print(f"Exception in list_users: {str(e)}")
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500 