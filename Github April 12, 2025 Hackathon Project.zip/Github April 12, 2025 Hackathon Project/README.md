# Blockchain Banking System

A simple blockchain-based banking system built with Flask and Polygon, allowing users to perform basic banking operations on the blockchain.

## Features

- Check account balance
- Deposit funds
- Withdraw funds
- Transfer funds between accounts
- Modern and responsive UI
- Real-time transaction status updates

## Prerequisites

- Python 3.8 or higher
- Metamask wallet with some MATIC tokens (for Polygon Mumbai testnet)
- Infura account for Polygon API access

## Setup

1. Clone the repository:
```bash
git clone <repository-url>
cd blockchain-banking-system
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Configure environment variables:
   - Copy `.env.example` to `.env`
   - Add your Infura project URL
   - Add your wallet's private key
   - Add your deployed smart contract address

4. Run the application:
```bash
python app.py
```

5. Access the application at `http://localhost:5000`

## Smart Contract Deployment

1. Deploy the smart contract to Polygon Mumbai testnet using Remix IDE or Hardhat
2. Copy the deployed contract address to your `.env` file
3. Ensure you have the contract ABI in `contract_abi.json`

## Security Notes

- Never commit your private keys or sensitive information to version control
- Use environment variables for all sensitive data
- Only use test networks (Mumbai) for development
- Always verify transactions before signing them

## License

MIT License 