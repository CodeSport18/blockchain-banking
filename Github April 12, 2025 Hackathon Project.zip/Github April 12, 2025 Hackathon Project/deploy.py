from web3 import Web3
from dotenv import load_dotenv
import os
import json
import time

# Load environment variables
load_dotenv()

# Connect to Sepolia network
w3 = Web3(Web3.HTTPProvider(os.getenv("INFURA_URL")))

# Contract ABI (consistent with our Banking.sol contract)
CONTRACT_ABI = [
    {
        "anonymous": False,
        "inputs": [
            {
                "indexed": True,
                "internalType": "address",
                "name": "account",
                "type": "address"
            },
            {
                "indexed": False,
                "internalType": "uint256",
                "name": "amount",
                "type": "uint256"
            }
        ],
        "name": "Deposit",
        "type": "event"
    },
    {
        "anonymous": False,
        "inputs": [
            {
                "indexed": True,
                "internalType": "address",
                "name": "from",
                "type": "address"
            },
            {
                "indexed": True,
                "internalType": "address",
                "name": "to",
                "type": "address"
            },
            {
                "indexed": False,
                "internalType": "uint256",
                "name": "amount",
                "type": "uint256"
            }
        ],
        "name": "Transfer",
        "type": "event"
    },
    {
        "anonymous": False,
        "inputs": [
            {
                "indexed": True,
                "internalType": "address",
                "name": "account",
                "type": "address"
            },
            {
                "indexed": False,
                "internalType": "uint256",
                "name": "amount",
                "type": "uint256"
            }
        ],
        "name": "Withdrawal",
        "type": "event"
    },
    {
        "inputs": [],
        "name": "deposit",
        "outputs": [],
        "stateMutability": "payable",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "address",
                "name": "account",
                "type": "address"
            }
        ],
        "name": "getBalance",
        "outputs": [
            {
                "internalType": "uint256",
                "name": "",
                "type": "uint256"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "address",
                "name": "to",
                "type": "address"
            },
            {
                "internalType": "uint256",
                "name": "amount",
                "type": "uint256"
            }
        ],
        "name": "transfer",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "uint256",
                "name": "amount",
                "type": "uint256"
            }
        ],
        "name": "withdraw",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "stateMutability": "payable",
        "type": "receive"
    },
    {
        "stateMutability": "payable",
        "type": "fallback"
    }
]

# Bytecode of the Banking.sol contract
CONTRACT_BYTECODE = "0x608060405234801561001057600080fd5b50610771806100206000396000f3fe6080604052600436106100435760003560e01c806327e235e31461004e57806347e7ef2414610089578063a9059cbb146100a5578063d0e30db0146100ce5761004c565b3661004c5761008956b005b34801561005a57600080fd5b5061007560048036038101906100709190610549565b6100e6565b60405161008091906105b1565b60405180910390f35b6100a360048036038101906100a691906105cc565b6100fe565b005b3480156100b157600080fd5b506100cc60048036038101906100c79190610549565b6101ac565b005b6100d66102e6565b005b60008060008373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff168152602001908152602001600020549050919050565b60008111610141576040517f08c379a0000000000000000000000000000000000000000000000000000000008152600401610138906106c2565b60405180910390fd5b346000803373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060008282546101909190610711565b925050819055503373ffffffffffffffffffffffffffffffffffffffff167f5548c837ab068cf56a2c2479df0882a4922fd203edb7517321831d95078c5f623460405161019e91906105b1565b60405180910390a250565b600073ffffffffffffffffffffffffffffffffffffffff168273ffffffffffffffffffffffffffffffffffffffff1614156101f2576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004016101e990610697565b60405180910390fd5b60008111610235576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040161022c9061066c565b60405180910390fd5b806000803373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff168152602001908152602001600020541015610288576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040161027f906106e7565b60405180910390fd5b806000803373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060008282546102d79190610767565b92505081905550806000808473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060008282546103279190610711565b925050819055503373ffffffffffffffffffffffffffffffffffffffff168273ffffffffffffffffffffffffffffffffffffffff167f3990db2d31862302a685e8086b5755072a6e2b5b780af1ee81ece35ee3cd334584604051610389919061066c565b60405180910390a3505050565b60008111610329576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040161032090610642565b60405180910390fd5b806000803373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002054101561037c576040517f08c379a0000000000000000000000000000000000000000000000000000000008152600401610373906106e7565b60405180910390fd5b806000803373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060008282546103cb9190610767565b925050819055503373ffffffffffffffffffffffffffffffffffffffff166108fc829081150290604051600060405180830381858888f19350505050158015610414573d6000803e3d6000fd5b503373ffffffffffffffffffffffffffffffffffffffff167ff279e6a1f5e320cca91135676d9cb6e44ca8a08c0b88342bcdb1144f6511b5688260405161045b91906105b1565b60405180910390a250565b6000604051905090565b600080fd5b600080fd5b600073ffffffffffffffffffffffffffffffffffffffff82169050919050565b600061049b82610470565b9050919050565b6104ab81610490565b81146104b657600080fd5b50565b6000813590506104c8816104a2565b92915050565b60006104d9826106ec565b6104e4816105f4565b905081810301518060101b8085013581811060195b8181111561050a576105095761052c565b5b90508181101561053157610526610537565b5b50919050565b60006020828403121561054157610540610466565b5b600061054f848285016104b9565b91505092915050565b60006020828403121561055f5761055e610466565b5b600061056d848285016104b9565b91505092915050565b6000819050919050565b61058981610576565b82525050565b61059881610536565b82525050565b6105a781610490565b82525050565b60006020820190506105c26000830184610580565b92915050565b6000604082840312156105e2576105e1610466565b5b60006105f0848285016104b9565b91505092915050565b6000819050919050565b6000602082840312156105f45761061d565b5b600082013560ff811115610618578283fd5b61062084828501610502565b91505092915050565b6000606082019050818103600083015261064380610652565b90509291505050565b6000602082019050818103600083015261066b8161066c565b9050919050565b60006020820190506106876000830184610580565b92915050565b600060208201905081810360008301528161069a81610682565b9050919050565b60006020820190506106b260008301846105c2565b92915050565b60006020820190506106cd60008301846106a9565b92915050565b600082825260208201905092915050565b60006106ef826106e7565b9050919050565b600061070182610576565b91506107138261075f565b9250827fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff03821115610748576107476106ec565b5b828201905092915050565b60008261074e575060d36401000000009050610766565b60019050919050565b600061077282610576565b915061077d83610576565b9250828261078d5761078c610787565b5b8282039050919050565b60008160011c9050919050565b600061079e85610400565b91506107a8856107a4565b9250826107b4576107b96107c3565b5b828204905092915050565b60008419905092915050565b634e487b7160e01b600052601260045260246000fd5b634e487b7160e01b600052601160045260246000fd5b634e487b7160e01b600052603260045260246000fd5b60006108118261037d565b915061081c8361037d565b92508261082c5761082b6107e7565b5b828206905092915050565b600082825260208201905092915050565b7f496e73756666696369656e742062616c616e6365000000000000000000000000600082015250565b7f5769746864726177616c20616d6f756e74206d757374206265206772656174656000830152692072207468616e20360b82015260110190565b7f43616e6e6f74207472616e7366657220746f207a65726f2061646472657373006000820152602001565b7f5472616e7366657220616d6f756e74206d757374206265206772656174657220600082015266746861ee103a3760c91b602082015260300190565b7f4465706f73697420616d6f756e74206d7573742062652067726561746572207460008201526a68616e2030206574686560a81b602082015260230190565b50348256"

try:
    print("Starting deployment to Sepolia...")
    
    # Get account from private key
    private_key = os.getenv("PRIVATE_KEY")
    if not private_key.startswith('0x'):
        private_key = '0x' + private_key
    account = w3.eth.account.from_key(private_key)

    print(f"Deploying from address: {account.address}")

    # Create contract instance
    Contract = w3.eth.contract(abi=CONTRACT_ABI, bytecode=CONTRACT_BYTECODE)

    # Get nonce
    nonce = w3.eth.get_transaction_count(account.address)

    # Get current gas price and increase it by 20%
    gas_price = w3.eth.gas_price
    gas_price = int(gas_price * 1.2)

    # Build transaction with higher gas limit
    transaction = Contract.constructor().build_transaction({
        'from': account.address,
        'nonce': nonce,
        'gas': 3000000,  # Increased gas limit
        'gasPrice': gas_price
    })

    print(f"Estimated gas price: {w3.from_wei(gas_price, 'gwei')} gwei")
    print(f"Estimated total cost: {w3.from_wei(gas_price * 3000000, 'ether')} ETH")

    # Sign transaction
    signed_txn = w3.eth.account.sign_transaction(transaction, private_key=private_key)

    # Send transaction
    tx_hash = w3.eth.send_raw_transaction(signed_txn.raw_transaction)
    print(f"Transaction sent! Hash: {tx_hash.hex()}")

    # Wait for transaction receipt with timeout
    print("Waiting for transaction to be mined...")
    start_time = time.time()
    while time.time() - start_time < 120:  # 2 minute timeout
        try:
            tx_receipt = w3.eth.get_transaction_receipt(tx_hash)
            if tx_receipt is not None:
                contract_address = tx_receipt['contractAddress']
                print(f"Contract deployed at: {contract_address}")
                break
        except:
            time.sleep(2)
            continue
        time.sleep(2)
    else:
        raise Exception("Transaction taking too long. Please check the transaction hash.")

    # Save contract address and ABI
    print("Saving contract information...")
    
    # Update .env file
    with open('.env', 'r') as f:
        env_lines = f.readlines()

    with open('.env', 'w') as f:
        for line in env_lines:
            if line.startswith('CONTRACT_ADDRESS='):
                f.write(f'CONTRACT_ADDRESS={contract_address}\n')
            else:
                f.write(line)

    # Save ABI
    with open('contract_abi.json', 'w') as f:
        json.dump(CONTRACT_ABI, f, indent=2)

    print("Done! Contract information saved.")
    print(f"\nYou can view your transaction at: https://sepolia.etherscan.io/tx/{tx_hash.hex()}")

except Exception as e:
    print(f"Error occurred: {str(e)}")
    print("\nPlease make sure you have:")
    print("1. Sufficient Sepolia ETH for gas (at least 0.01 ETH)")
    print("2. Correct private key in .env")
    print("3. Valid Alchemy URL in .env")
    print("\nIf you need Sepolia ETH, get some from:")
    print("https://sepoliafaucet.com/") 