import pymongo
from flask_bcrypt import Bcrypt
from pymongo import MongoClient
from bson.objectid import ObjectId
import os
from dotenv import load_dotenv
import datetime
import traceback

# Load environment variables
load_dotenv()

# Initialize bcrypt
bcrypt = Bcrypt()

# Connect to MongoDB
try:
    mongo_uri = os.getenv("MONGO_URI")
    print(f"Connecting to MongoDB: {mongo_uri}")
    
    client = MongoClient(mongo_uri)
    # Test connection
    client.admin.command('ping')
    print("MongoDB connection successful!")
    
    db = client.blockchain_banking  # Database name
    
    # Collections
    users = db.users
    transactions = db.transactions
    
    # Create indexes (if they don't exist)
    users.create_index([("username", pymongo.ASCENDING)], unique=True)
    users.create_index([("email", pymongo.ASCENDING)], unique=True)
    users.create_index([("eth_address", pymongo.ASCENDING)], unique=True)
    
except Exception as e:
    print(f"MongoDB connection error: {str(e)}")
    traceback.print_exc()
    # Set up dummy collections for fallback (development mode)
    class DummyCollection:
        def __init__(self):
            self.data = []
            self._id_counter = 1
        
        def insert_one(self, document):
            document["_id"] = self._id_counter
            self._id_counter += 1
            self.data.append(document)
            class Result:
                @property
                def inserted_id(self):
                    return document["_id"]
            return Result()
        
        def find_one(self, query):
            for doc in self.data:
                match = True
                for key, value in query.items():
                    if key == "$or":
                        or_match = False
                        for or_condition in value:
                            sub_match = True
                            for sub_key, sub_value in or_condition.items():
                                if doc.get(sub_key) != sub_value:
                                    sub_match = False
                                    break
                            if sub_match:
                                or_match = True
                                break
                        if not or_match:
                            match = False
                            break
                    elif doc.get(key) != value:
                        match = False
                        break
                if match:
                    return doc
            return None
        
        def update_one(self, query, update):
            doc = self.find_one(query)
            if doc:
                for key, value in update.get("$set", {}).items():
                    doc[key] = value
                class Result:
                    @property
                    def modified_count(self):
                        return 1
                return Result()
            class Result:
                @property
                def modified_count(self):
                    return 0
            return Result()
        
        def count_documents(self, query):
            count = 0
            for doc in self.data:
                match = True
                for key, value in query.items():
                    if doc.get(key) != value:
                        match = False
                        break
                if match:
                    count += 1
            return count
        
        def create_index(self, fields, **kwargs):
            pass
    
    class DummyDB:
        def __init__(self):
            self.users = DummyCollection()
            self.transactions = DummyCollection()
        
        def list_collection_names(self):
            return ["users", "transactions"]
    
    print("Using in-memory database for development")
    db = DummyDB()
    users = db.users
    transactions = db.transactions

def create_user(username, email, password, eth_address):
    """
    Create a new user in the database
    """
    try:
        # Check if username or email already exists
        if users.find_one({"$or": [{"username": username}, {"email": email}]}):
            return None, "Username or email already exists"
        
        # Check if ethereum address is already registered
        if users.find_one({"eth_address": eth_address}):
            return None, "Ethereum address already registered"
        
        # Hash the password
        hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')
        
        # Create user document
        user = {
            "username": username,
            "email": email,
            "password": hashed_password,
            "eth_address": eth_address,
            "created_at": datetime.datetime.utcnow(),
            "is_active": True
        }
        
        # Insert into database
        result = users.insert_one(user)
        user["_id"] = str(result.inserted_id)
        
        # Don't return the password
        del user["password"]
        return user, None
    except Exception as e:
        print(f"Error creating user: {str(e)}")
        traceback.print_exc()
        return None, str(e)

def authenticate_user(email_or_username, password):
    """
    Authenticate a user by email/username and password
    """
    try:
        # Find user by email or username
        user = users.find_one({"$or": [{"email": email_or_username}, {"username": email_or_username}]})
        
        if not user:
            return None, "Invalid credentials"
        
        # Check password
        if not bcrypt.check_password_hash(user["password"], password):
            return None, "Invalid credentials"
        
        # Convert ObjectID to string for JSON serialization
        user["_id"] = str(user["_id"])
        
        # Don't return the password
        del user["password"]
        return user, None
    except Exception as e:
        print(f"Error authenticating user: {str(e)}")
        traceback.print_exc()
        return None, str(e)

def get_user_by_id(user_id):
    """
    Get a user by their ID
    """
    try:
        user = users.find_one({"_id": ObjectId(user_id)})
        if user:
            user["_id"] = str(user["_id"])
            del user["password"]  # Don't return the password
            return user
        return None
    except Exception as e:
        print(f"Error getting user by ID: {str(e)}")
        traceback.print_exc()
        return None

def get_user_by_eth_address(eth_address):
    """
    Get a user by their Ethereum address
    """
    try:
        user = users.find_one({"eth_address": eth_address})
        if user:
            user["_id"] = str(user["_id"])
            del user["password"]  # Don't return the password
            return user
        return None
    except Exception as e:
        print(f"Error getting user by ETH address: {str(e)}")
        traceback.print_exc()
        return None

def update_user(user_id, update_data):
    """
    Update user information
    """
    try:
        # Don't allow updates to these fields
        if "password" in update_data:
            del update_data["password"]
        if "_id" in update_data:
            del update_data["_id"]
        
        # Update the user
        result = users.update_one(
            {"_id": ObjectId(user_id)},
            {"$set": update_data}
        )
        
        if result.modified_count > 0:
            return True
        return False
    except Exception as e:
        print(f"Error updating user: {str(e)}")
        traceback.print_exc()
        return False

def record_transaction(user_id, transaction_type, amount, tx_hash, status="pending", to_address=None):
    """
    Record a blockchain transaction
    """
    try:
        transaction = {
            "user_id": user_id,
            "transaction_type": transaction_type,  # deposit, withdraw, transfer
            "amount": amount,
            "tx_hash": tx_hash,
            "status": status,
            "timestamp": datetime.datetime.utcnow()
        }
        
        # Add to_address if provided (for transfers)
        if to_address:
            transaction["to_address"] = to_address
        
        result = transactions.insert_one(transaction)
        transaction["_id"] = str(result.inserted_id)
        return transaction
    except Exception as e:
        print(f"Error recording transaction: {str(e)}")
        traceback.print_exc()
        return None 