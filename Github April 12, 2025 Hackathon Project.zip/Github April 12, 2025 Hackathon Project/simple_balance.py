from web3 import Web3

# Your wallet address
address = "0x5531E57644628C775fC3a4EB1968e027e7727E9F"

# Connect directly to Sepolia using Infura
w3 = Web3(Web3.HTTPProvider("https://sepolia.infura.io/v3/1be81447c06c4d70881421f36e011689"))

print(f"Connection status: {w3.is_connected()}")
print(f"Checking balance for: {address}")

# Get native ETH balance
balance_wei = w3.eth.get_balance(address)
balance_eth = w3.from_wei(balance_wei, 'ether')

print(f"Sepolia ETH Balance: {balance_eth} ETH")
print(f"Sepolia ETH Balance (wei): {balance_wei} wei") 