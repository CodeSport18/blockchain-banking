from web3 import Web3
from dotenv import load_dotenv
import os
import json

# Load environment variables
load_dotenv()

# Connect to Sepolia network
infura_url = os.getenv("INFURA_URL")
print(f"Connecting to: {infura_url}")
w3 = Web3(Web3.HTTPProvider(infura_url))
if not w3.is_connected():
    print("Failed to connect to Ethereum network!")
    exit(1)
else:
    print(f"Connected to Ethereum network: {w3.client_version}")

# Use the provided address
address = "0x5531E57644628C775fC3a4EB1968e027e7727E9F"
print(f"\n=== WALLET INFO ===")
print(f"Address: {address}")

# Get native ETH balance
native_balance = w3.eth.get_balance(address)
native_eth = w3.from_wei(native_balance, 'ether')
print(f"Native Sepolia ETH balance: {native_eth} ETH")

# Connect to contract
try:
    with open("contract_abi.json") as f:
        abi = json.load(f)
    
    contract_address = os.getenv("CONTRACT_ADDRESS")
    if contract_address:
        contract = w3.eth.contract(address=Web3.to_checksum_address(contract_address), abi=abi)
        print(f"\n=== CONTRACT INFO ===")
        print(f"Contract address: {contract_address}")
        
        # Get contract balance
        try:
            contract_balance = contract.functions.getBalance(address).call()
            contract_eth = w3.from_wei(contract_balance, 'ether')
            print(f"Your balance in contract: {contract_eth} ETH")
        except Exception as e:
            print(f"No funds in contract yet: {str(e)}")
            print("You need to deposit funds into the contract first.")
    else:
        print("CONTRACT_ADDRESS not found in .env file")
except Exception as e:
    print(f"Error connecting to contract: {str(e)}")

print("\nTo deposit funds from your wallet to the contract:")
print("1. Start your Flask app: python3 app.py")
print("2. Make a POST request to http://localhost:5000/deposit with JSON body: {\"amount\": 1000000000000000000}")
print("   (The amount is in wei, this example is 1 ETH)") 